VC15 x64 Non Thread Safe compiled LibXL plug-in for PHP 7.4
(Ilia Alshanetsky https://github.com/iliaal/php_excel)
